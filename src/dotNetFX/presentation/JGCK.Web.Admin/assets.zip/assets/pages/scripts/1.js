{
    "name": "Name1 ",
        "children": [
            {
                "name": "Name: A",
                "ID": 2
            },
            {
                "name": "Name: B",
                "ID": 3
            },
            {
                "name": "Name: C",
                "ID": 4
            },
            {
                "name": "Name: D",
                "ID": 5
            },
            {
                "name": "Name: E",
                "ID": 6
            }
        ]
}
